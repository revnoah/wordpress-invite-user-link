<?php

/**
 * Define settings fields
 *
 * @return array
 */
function invite_user_link_invite_fields() {
	$settings = [
		'id' => 'invite_user_link_invite',
		'kabob' => 'invite-user-link-invite',
		'label' => __('Invite User'),
		'settings' => [[
			'id' => 'invite_user_link_number_users',
			'label' => __('Number Of Users To Create'),
			'type' => 'text',
			'default' => '1'
		], [
			'id' => 'invite_user_link_expiry_date',
			'label' => __('Expiry Date'),
			'type' => 'date',
			'default' => ''
		], [
            'id' => 'invite_user_link_require_email_address',
			'label' => __('Require Email Address'),
			'type' => 'boolean',
			'default' => false
		], [
			'id' => 'invite_user_link_require_email_verification',
			'label' => __('Require Email Verification'),
			'type' => 'boolean',
			'default' => false
		], [
			'id' => 'invite_user_link_require_approval',
			'label' => __('Require Approval'),
			'type' => 'boolean',
			'default' => false
		]]
	];

	return $settings;
}


/**
 * Invite user or users
 *
 * @return void
 */
function invite_user_link_users_menu() {
	$settings = invite_user_link_invite_fields();

    add_users_page(
        $settings['label'], 
        $settings['label'], 
        'read', 
        $settings['kabob'], 
        'invite_user_link_invite'
    );
}

/**
 * Invite user
 *
 * @return void
 */
function invite_user_link_invite() {
	//load user settings
	$settings = invite_user_link_settings_fields();
	?>
	<div class="wrap">
	<h1><?php echo $settings['label']; ?></h1>

	<form method="post" action="options.php">
		<?php settings_fields($settings['kabob'] . '-settings-group'); ?>
		<?php do_settings_sections($settings['kabob'] . '-settings-group'); ?>

		<table class="form-table">
			<?php
			foreach ($settings['settings'] as $setting) {
				$setting['saved'] = get_option($setting['id'], $setting['default']);
				echo invite_user_link_get_formatted_field($setting);
				?>
			<?php
			}
			?>
		</table>

		<?php submit_button(); ?>
	</form>

</div>
<?php
}
